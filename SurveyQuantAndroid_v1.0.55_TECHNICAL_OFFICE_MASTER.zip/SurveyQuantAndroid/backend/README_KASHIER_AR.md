# مكتب فني مساحة + Kashier

الدفع يتم بدون بريد إلكتروني وبدون إنشاء حساب يدوي. التطبيق يولد معرف جهاز محليًا ويربط به الاشتراك.

## Environment
- KASHIER_MODE=test أو live
- KASHIER_MID
- KASHIER_API_KEY
- KASHIER_SECRET_KEY
- PUBLIC_BASE_URL

## Webhook
https://YOUR-BACKEND-DOMAIN/api/kashier/webhook

المفتاح السري يبقى على السيرفر فقط.
